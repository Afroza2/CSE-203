#include<stdio.h>
#include<stdlib.h>

#define LIST_INIT_SIZE 2
#define NULL_VALUE -99999
#define SUCCESS_VALUE 99999

int listMaxSize;
int * list;
int length;


void initializeList()
{
	listMaxSize = LIST_INIT_SIZE;
	list = (int*)malloc(sizeof(int)*listMaxSize) ;
	length = 0 ;
}

int getLength()
{
    return length;
}

int searchItem(int item)
{
	int i = 0;
	for (i = 0; i < length; i++)
	{
		if( list[i] == item ) return i;
	}
	return NULL_VALUE;
}

int insertItem(int newitem)
{
	int * tempList ;
	if(listMaxSize==0) initializeList();
	else if (length == listMaxSize)
	{
		//allocate new memory space for tempList
		listMaxSize = 2 * listMaxSize ;
		tempList = (int*) malloc (listMaxSize*sizeof(int)) ;
		int i;
        for( i = 0; i < length ; i++ )
        {
            tempList[i] = list[i] ; //copy all items from list to tempList
        }
        free(list) ; //free the memory allocated before
        list = tempList ; //make list to point to new memory
	};

	list[length] = newitem ; //store new item
	length++ ;
	return SUCCESS_VALUE ;
}

int insertItemAt(int pos, int item)
{
    int x;
    if(pos<0 || pos>=length) return NULL_VALUE;
    else
    {
      x=list[pos];
      list[pos]=item;
      insertItem(x);
      return SUCCESS_VALUE;
    }
}

int shrink()
{
    int *tempList;
    if(listMaxSize==LIST_INIT_SIZE) return SUCCESS_VALUE;
    else if (length<=listMaxSize/2)
    {
		listMaxSize = listMaxSize/2 ;
		tempList = (int*) malloc (listMaxSize*sizeof(int)) ;
		int i;
        for( i = 0; i < length ; i++ )
        {
            tempList[i] = list[i] ;
        }
        free(list) ;
        list = tempList ;

    }
    return SUCCESS_VALUE;
}


int deleteItemAt(int position) //version 2, do not preserve order of items
{
	if ( position >= length ) return NULL_VALUE;
	list[position] = list[length-1] ;
	length-- ;
	shrink();
	return SUCCESS_VALUE ;
}


int deleteItem(int item)
{
	int position;
	position = searchItem(item) ;
	if ( position == NULL_VALUE ) return NULL_VALUE;
	deleteItemAt(position) ;
	return SUCCESS_VALUE ;
}

int deleteLast()
{
    deleteItemAt(length-1);
    return SUCCESS_VALUE;
}

int deleteAll()
{
    int *tempList;
    listMaxSize = LIST_INIT_SIZE ;
    tempList = (int*) malloc (listMaxSize*sizeof(int));
    free(list);
    list=tempList;
    length=0;
    return SUCCESS_VALUE;
}

int clear()
{
    free(list);
    listMaxSize=0;
    length=0;
    return SUCCESS_VALUE;
}

void printList()
{
    int i;
    for(i=0;i<length;i++)
        printf("%d ", list[i]);
    printf("Current size: %d, current length: %d\n", listMaxSize, length);
}

/*int main(void)
{
    initializeList();
    while(1)
    {
        printf("1. Insert new item. 2. Delete item at. 3. Delete item.\n");
        printf("4. Insert new item at. 5. Delete last 6. Delete all\n");
        printf("7. clear list 8. Print. 9. exit.\n");

        int ch;
        scanf("%d",&ch);
        if(ch==1)
        {
            int item;
            scanf("%d", &item);
            insertItem(item);
        }
        else if(ch==2)
        {
            int pos;
            scanf("%d", &pos);
            deleteItemAt(pos);
        }
        else if(ch==3)
        {
            int item;
            scanf("%d", &item);
            deleteItem(item);
        }
        else if(ch==4)
        {
            int pos,item;
            scanf("%d %d", &pos, &item);
            insertItemAt(pos,item);
        }
        else if(ch==5)
        {
            deleteLast();
        }
        else if(ch==6)
        {
            deleteAll();
        }
        else if(ch==7)
        {
            clear();
        }
        else if(ch==8)
        {
            printList();
        }
        else if(ch==9)
        {
            break;
        }
    }

}*/

int main(void)
{
    initializeList();
    while(1)
    {
        printf("1. Give the input string. 2. Exit.\n");

        int op;
        scanf("%d",&op);
        if(op==1)
        {
            char ch[20],prev;
            int i=0,j,flag=0;
            scanf("%s",ch);
            while(ch[i])
            {
                if(ch[i]=='('||ch[i]=='{'||ch[i]=='[') insertItem(ch[i]);
                else if(ch[i]==')'||ch[i]=='}'||ch[i]==']')
                {
                    if(length==0)
                    {
                        flag=1;
                        printf("Not Balanced\n");
                        break;
                    }
                    else
                    {
                        prev=list[length-1];

                        if((prev=='('&&ch[i]==')')||(prev=='{'&&ch[i]=='}')||(prev=='['&&ch[i]==']'))
                        {
                            deleteLast();
                        }
                        else
                        {
                            flag=1;
                            break;
                        }
                    }
                }
                i++;
            }
            j=getLength();
            if(flag==1 && j!=0) printf("Not Balanced\n");
            else if(flag==0 && j==0) printf("Balanced\n");
            clear();
        }
        else if(op==2)
        {
            break;
        }
    }
    return 0;
}
